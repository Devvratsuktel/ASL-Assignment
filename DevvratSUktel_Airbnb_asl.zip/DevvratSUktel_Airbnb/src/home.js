import './home.css'

export default function Home(){
return (
  <div>
    <h1 class="txt">New this week</h1>
<div class="row ">


      <div class="column">
        <img
          class="pic"
          src="https://a0.muscache.com/im/pictures/e35bb307-05f4-48a4-bdc5-3b2198bb9451.jpg?im_w=720"
          alt=""
        />
      </div>

      <div class="column">
        <img
          src="https://a0.muscache.com/im/pictures/58819d01-2a71-441d-b3bc-baae0cd64da1.jpg?im_w=720"
          alt=""
        />
      </div>
      <div class="column">
        <img
          src="https://a0.muscache.com/im/pictures/bcbd20bb-1654-4ea2-a86c-2cf25666f3b6.jpg?im_w=720"
          alt=""
        />
      </div>
    </div>
 
    </div>
// </div>
  

);


}