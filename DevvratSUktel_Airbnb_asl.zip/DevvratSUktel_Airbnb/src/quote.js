export default function Quote() {
  return (
    <div class="outer">
    <div class="container">
    <div class="notmove" >
        
        
    </div>  
    <div class="scrollmenu"> 
    <button class="btn">Dates</button>
        <button class="btn">Group size</button>
        <button class="btn">More filters</button>
         <button class="btn">great for groups</button> 
        <button class="btn">Family-friendly</button>
        <button class="btn">Animals</button>
        <button class="btn">Arts & writing </button>
        <button class="btn">Baking</button>
        <button class="btn">Cooking</button>
        <button class="btn">Dance</button>
        <button class="btn">Drinks</button>
        <button class="btn">Entertainment</button>
        <button class="btn">Fitness</button>
        <button class="btn">History & culture</button>
        <button class="btn">Magic</button>
        <button class="btn">Music</button>
        <button class="btn">Social impact</button>
        <button class="btn">Wellness</button>
        <button class="btn">olympian & Paralympians</button>
        <button class="btn">Designed for accessibility</button>
       
    </div>
</div>
    
      {/* <div class="_5kaapu">
        <div class="_1kp11sq">
          <div class="_e296pg">
            <div>
              <div
                id="menuItemButton-date_picker"
                data-testid="menuItemButton-date_picker"
                class="_7yfwnp"
              >
                <button class="_15pf4i2" aria-expanded="false" type="button">
                  <span class="_w37zq5">
                    <div class="_1e69mqj">
                      <span class="_36rlri">Dates</span>
                    </div>
                  </span>
                  <span class="a8jt5op dir dir-ltr">Filter not applied</span>
                  <span aria-hidden="true" class="_1vwho579">
                    <span class="_w37zq5">
                      <div class="_1e69mqj">
                        <span class="_36rlri">Dates</span>
                      </div>
                    </span>
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="_1kp11sq">
          <div class="_e296pg">
            <div>
              <div
                id="menuItemButton-experience_group_size"
                data-testid="menuItemButton-experience_group_size"
                class="_7yfwnp"
              >
                <button class="_15pf4i2" aria-expanded="false" type="button">
                  <span class="_w37zq5">
                    <div class="_1e69mqj">
                      <span class="_36rlri">Group size</span>
                    </div>
                  </span>
                  <span class="a8jt5op dir dir-ltr">No Filter applied</span>
                  <span aria-hidden="true" class="_1vwho579">
                    <span class="_w37zq5">
                      <div class="_1e69mqj">
                        <span class="_36rlri">Group size</span>
                      </div>
                    </span>
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="_7yfwnp">
          <button class="_15pf4i2" type="button">
            <span class="_w37zq5">More filters</span>
            <span class="a8jt5op dir dir-ltr">No Filter applied</span>
            <span aria-hidden="true" class="_1vwho579">
              <span class="_w37zq5">More filters</span>
            </span>
          </button>
        </div>
      </div> */}
    </div>
  );
}
