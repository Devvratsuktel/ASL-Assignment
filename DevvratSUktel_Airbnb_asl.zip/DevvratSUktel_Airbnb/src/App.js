import './App.css';
import Header from './header.js';
import Home from './home';
import Topseller from './topseller';
import 'bootstrap/dist/css/bootstrap.min.css';
import Quote from './quote';
import {BrowserRouter as Router, Switch, Route} from "react-router-dom";

function App() {
  return (

    
<div className="App">
    <Header/>
    <Home />
    <Quote/>
    
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br><br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
    <Topseller/>   
 </div>
  );
}

export default App;
