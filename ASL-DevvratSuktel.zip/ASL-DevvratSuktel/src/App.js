import './App.css';
import Header from './header.js';
import Home from './home';
import Topseller from './topseller';
import 'bootstrap/dist/css/bootstrap.min.css';
import Quote from './quote';


function App() {
  return (

    
<div className="App">
    <Header/>
    <Home />
    <br></br>
    <Quote/>
    <br></br>
    
    <Topseller/>   
 </div>
  );
}

export default App;
