import 'bootstrap/dist/css/bootstrap.min.css';

export default function Quote() {
  return (
  
      

      <div class="a">

<div class="btn-group" role="toolbar" aria-label="Toolbar with button groups" >

<div class="btn-group mr-2" role="group" aria-label="First group">
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:70,width:100,height:30  }}>Dates</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:120 ,height:30}}>Group Size</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,height:30 ,width:110  }}>More filters</button>
          <span   class="vl"> &nbsp; | &nbsp;  </span>
          </div>
          <span>
          <div class="btn-group mr-2" style={{}} role="group" aria-label="Second group" >
          
         <button class="rounded-pill secondary,border border-light" style={{marginLeft:10 ,width:150}}>great for groups</button>
          <button class="rounded-pill secondary,border border-light"  style={{marginLeft:10,width:140 }}>Family-friendly</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:80 }}>Animals</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:130 }}>Arts & writing </button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:80 }}>Baking</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10 ,width:100}}>Cooking</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10 ,width:70}}>Dance</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10 ,width:70}}>Drinks</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:120 }}>Entertainment</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:80 }}>Fitness</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:150 }}>History & culture</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:70 }}>Magic</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10 ,width:70}}>Music</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10 ,width:130}}>Social impact</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10 ,width:100}}>Wellness</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:210 }}>olympian & Paralympians</button>
          <button class="rounded-pill secondary,border border-light"style={{marginLeft:10,width:210 }}>Designed for accessibility</button>
          </div>
          </span>
          </div>
        </div>
      
     

  
  );
}
