import "./topseller.css";
import {Card} from "react-bootstrap";
// import{AiFillStar} from "react-icons";
export default function Topseller() {
  return (
    <div>


<div class="plan"> 
  <h4><b>Plan a trip with help from local hosts around the world</b></h4>
</div>
<br></br>

   <div class="img12">
      <div class="s5">

<Card style={{ width: '13rem' }}>
<Card.Img orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-2496585-poster/original/e6de8fae-018d-4411-b0a3-81bbb6e4e5c3.jpeg?im_w=720"
               />
<Card.Body style={{ height:'150px'}}>
<Card.Title>United States</Card.Title>
<Card.Text >
<p>
 Plan The Perfect New York <br></br> Vacation<br></br>
<b> From 1,562</b>/person</p>

</Card.Text>

</Card.Body>
</Card>
</div>
<div class="s6">

      <Card style={{ width: '13rem' }}>
  <Card.Img orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-2488061-active_media/original/2d2c8d93-f9fc-48c3-975a-84fec4fb951c.jpeg?im_w=720"
              />
  <Card.Body style={{ height:'150px'}}>
    <Card.Title>Spain</Card.Title>
    <Card.Text >
      <p>
        Design your trip to Barcelona<br></br> with Gemma<br></br>
      <b> From 3,131</b>/person</p>
      
    </Card.Text>
    
  </Card.Body>
</Card>
</div>
<div class="s7">
<Card style={{ width: '13rem' }}>
  <Card.Img orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-2563542-poster/original/391d04f5-6823-4a9b-a7e4-c86968325e7c.jpeg?im_w=720"
             
              />
  <Card.Body style={{ height:'150px'}}>
    <Card.Title>South Korea</Card.Title>
    <Card.Text >
      <p>
        Cast a custom trip to Korea<br></br> with jay<br></br>
      <b> From 3,475</b>/person</p>
      
    </Card.Text>
    
  </Card.Body>
</Card>

      
</div>
<div class="s8">

      <Card style={{ width: '13rem' }}>
  <Card.Img orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-3010357-poster/original/6cdd0bd4-eac2-4657-ab1f-a429ebdafe37.jpeg?im_w=720"
              
              />
  <Card.Body style={{ height:'150px'}}>
    <Card.Title>Mexico</Card.Title>
    <Card.Text >
      <p>
        Live Tulum like a local<br></br>
      <b> From 620</b>/person</p>
      
    </Card.Text>
    
  </Card.Body>
</Card>
</div>
<div class="s9">

      <Card style={{ width: '13rem' }}>
  <Card.Img orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-3033220-media_library/original/5f7f9363-bbd9-4503-8bcf-ac0671eb34e1.jpg?im_w=720"
              
              />
  <Card.Body style={{ height:'150px'}}>
    <Card.Title>United States</Card.Title>
    <Card.Text >
      <p>
        Discover Sunny Fort<br></br> Lauderdale<br></br>
      <b> From 1,726</b>/person</p>
      
    </Card.Text>
    
  </Card.Body>
</Card>
</div>
<div class="s10">

      <Card style={{ width: '13rem' }}>
  <Card.Img  style={{ height: '270px' }} orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-3134396-active_media/original/e4f5bfb7-d45e-477b-a49f-e1bd7f85bcf0.jpg?im_w=720"
              />
  <Card.Body style={{ height:'150px'}}>
    <Card.Title>United States</Card.Title>
    <Card.Text >
      <p>
        Plan  a trip to amazing<br></br> Austin<br></br>
      <b> From 2,055</b>/person</p>
      
    </Card.Text>
    
  </Card.Body>
</Card>
</div>

        <div class="ss2">

      <Card style={{ width: '13rem' }}>
  <Card.Img orientation="top"  style={{ height: '270px' }}  src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-2596268-active_media/original/b0aa65da-e3f6-4bd2-91d3-9e2f127f348a.jpg?im_w=720"
              
              />
  <Card.Body style={{ height:'150px'}}>
    <Card.Title>Italy</Card.Title>
    <Card.Text >
      <p>
        Pasta from Grandmas<br></br>
      <b> From 2,719</b>/person</p>
      
    </Card.Text>
    
  </Card.Body>
</Card>
</div>
<div class="ss3">

<Card style={{ width: '13rem' }}>
<Card.Img orientation="top" src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-2493134-poster/original/235ca0ba-93c9-4e39-a41e-9013bc13142e.jpeg?im_w=720"
             
              />
<Card.Body style={{ height:'150px'}}>
<Card.Title>Poland</Card.Title>
<Card.Text >
<p>
  Crack the mystery Escape<br></br>Room Game<br></br>
<b> From 1,299</b>/person</p>

</Card.Text>

</Card.Body>
</Card>
</div>
<div class="ss4">

<Card style={{ width: '13rem' }}>
<Card.Img orientation="top" style={{ height: '270px' }} src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-2493583-media_library/original/230e98c2-f628-4a67-94b6-dcac3e94d2eb.jpeg?im_w=720"
              
             />
<Card.Body style={{ height:'150px'}}>
<Card.Title>Spain</Card.Title>
<Card.Text >
<p>
  'No Spain no Game' The <br></br>Fabulous Game<br></br>
<b> From 1,319</b>/person</p>

</Card.Text>

</Card.Body>
</Card>
</div>
<div class="ss5">

<Card style={{ width: '13rem' }}>
<Card.Img orientation="top" style={{ height: '270px' }}  src="https://a0.muscache.com/im/pictures/lombard/MtTemplate-3076506-active_media/original/1ea49a82-f447-40bc-8324-2d85a748b17e.jpg?im_w=720"
              
              />
<Card.Body style={{ height:'150px'}}>
<Card.Title>France</Card.Title>
<Card.Text >
<p>
  'From Paris with Laughs' The <br></br>Scavenger Hunt<br></br>
<b> From 1,154</b>/person</p>

</Card.Text>

</Card.Body>
</Card>
</div>



      
        


      </div>
    








    </div>



  );
}
